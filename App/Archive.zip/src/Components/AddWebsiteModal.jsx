import React, { useEffect, useState } from "react";
import { X } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { createWebsite } from "../redux/slice/websiteSlice";

const websiteCategories = [
    "Blog",
    "Movies",
    "Gaming",
    "Education",
    "Finance",
    "News",
    "Adult",
    "Tools",
    "Entertainment",
];

const adFormats = [
    { value: "Popunder", label: "Popunder" },
    { value: "Smartlink", label: "Smartlink" },
    { value: "Native Banner", label: "Native Banner" },
    { value: "Social Bar", label: "Social Bar" },
    { value: "Banner", label: "Banner" },
];

const AddWebsiteModal = ({ isOpen, setIsOpen }) => {

    const dispatch = useDispatch();
    const { loading } = useSelector((state) => state.website);

   const [formData, setFormData] = useState({
    website: "",
    websiteCategory: "",
    showAdultAds: false,
    adFormat: [],
});

    useEffect(() => {
        if (isOpen) {
            setFormData({
                website: "",
                websiteCategory: "",
                showAdultAds: false,
                adFormat: ["Popunder"],
            });
        }
    }, [isOpen]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;

        setFormData((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleAdFormatChange = (value) => {
        setFormData((prev) => ({
            ...prev,
            adFormat: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.website || !formData.websiteCategory) return;

        const res = await dispatch(createWebsite(formData));

        if (res?.meta?.requestStatus === "fulfilled") {
            setIsOpen(false);

            setFormData({
                website: "",
                websiteCategory: "",
                showAdultAds: false,
                adFormat: ["Popunder"],
            });
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <div className="w-full max-w-lg bg-white rounded-2xl shadow-xl">

                {/* Header */}
                <div className="px-6 pt-6 pb-4 border-b border-gray-200">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-bold text-gray-900">
                            Add new Website
                        </h2>

                        <button
                            type="button"
                            onClick={() => setIsOpen(false)}
                            className="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center"
                        >
                            <X className="w-5 h-5 text-gray-500" />
                        </button>
                    </div>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-5">

                    {/* Website URL */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Website
                        </label>

                        <input
                            type="text"
                            name="website"
                            value={formData.website}
                            onChange={handleChange}
                            placeholder="Enter website URL"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                    </div>

                    {/* Website Category */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Website category
                        </label>

                        <select
                            name="websiteCategory"
                            value={formData.websiteCategory}
                            onChange={handleChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="">Select category</option>

                            {websiteCategories.map((cat) => (
                                <option key={cat} value={cat}>
                                    {cat}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Adult Ads */}
                    <div className="space-y-3">
                        <div className="flex items-center gap-2">
                            <input
                                type="checkbox"
                                name="showAdultAds"
                                id="showAdultAds"
                                checked={formData.showAdultAds}
                                onChange={handleChange}
                                className="w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />

                            <label
                                htmlFor="showAdultAds"
                                className="text-sm font-medium text-gray-700"
                            >
                                Show adult ads
                            </label>
                        </div>

                        {formData.showAdultAds && (
                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                <div className="flex items-center gap-2 mb-2">
                                    <span className="text-blue-600 font-bold text-sm">⚡</span>

                                    <span className="text-sm font-semibold text-blue-800">
                                        BOOST YOUR CPM
                                    </span>
                                </div>

                                <p className="text-xs text-blue-600">
                                    Adult ads typically help to increase CPM and revenue.
                                </p>
                            </div>
                        )}
                    </div>

{/* Ad Format */}
<div>
    <label className="block text-sm font-medium text-gray-700 mb-3">
        Choose Ad Unit format
    </label>

    <div className="space-y-2">
        {adFormats.map((format) => (
            <label
                key={format.value}
                className="flex items-center gap-2 cursor-pointer"
            >
                <input
                    type="checkbox"
                    value={format.value}
                    checked={formData.adFormat?.includes(format.value)}
                    onChange={(e) => {
                        if (e.target.checked) {
                            setFormData((prev) => ({
                                ...prev,
                                adFormat: [...(prev.adFormat || []), format.value],
                            }));
                        } else {
                            setFormData((prev) => ({
                                ...prev,
                                adFormat: prev.adFormat.filter(
                                    (item) => item !== format.value
                                ),
                            }));
                        }
                    }}
                    className="w-4 h-4 border-gray-300 text-indigo-600 focus:ring-indigo-500 rounded"
                />

                <span className="text-sm text-gray-700">
                    {format.label}
                </span>
            </label>
        ))}
    </div>
</div>

                    {/* Buttons */}
                    <div className="flex items-center justify-end gap-3 pt-4">
                        <button
                            type="button"
                            onClick={() => setIsOpen(false)}
                            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                        >
                            Cancel
                        </button>

                        <button
                            type="submit"
                            disabled={
                                loading ||
                                !formData.website ||
                                !formData.websiteCategory
                            }
                            className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {loading ? "Please wait..." : "ADD"}
                        </button>
                    </div>

                </form>
            </div>
        </div>
    );
};

export default AddWebsiteModal;